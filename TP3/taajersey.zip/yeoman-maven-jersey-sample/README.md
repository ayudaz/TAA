#yeoman-maven-jersey-sample

Sample Jersey application from the [yeoman-maven-plugin](https://github.com/trecloux/yeoman-maven-plugin)
